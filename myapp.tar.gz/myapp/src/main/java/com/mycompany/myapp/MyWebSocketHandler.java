package com.mycompany.myapp;

import org.springframework.web.reactive.socket.WebSocketHandler;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Mono;

public class MyWebSocketHandler implements WebSocketHandler {
    @Override
    public Mono<Void> handle(WebSocketSession session) {
        // Handle incoming messages and send back responses
        return session.send(session.receive()
                .map(message -> "Server received: " + message.getPayloadAsText())
                .map(session::textMessage));
    }
}