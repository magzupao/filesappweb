import { Component } from '@angular/core';
import { WebSocketService } from './WebSocketService';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  message: string = '';
  messages: string[] = [];

  constructor(private webSocketService: WebSocketService) {
    this.webSocketService.onMessage().subscribe((message: string) => {
      this.messages.push(message);
    });
  }

  sendMessage() {
    this.webSocketService.send(this.message);
    this.message = '';
  }
}