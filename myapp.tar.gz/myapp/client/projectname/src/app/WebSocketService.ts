import { Injectable } from '@angular/core';
import { webSocket, WebSocketSubject } from 'rxjs/webSocket';

@Injectable({
  providedIn: 'root'
})
export class WebSocketService {
  private socket: WebSocketSubject<any>;

  constructor() {
    // Establece la URL del servidor WebSocket
    this.socket = webSocket('ws://localhost:8080/websocket'); // Reemplaza la URL con la del servidor WebSocket real
  }

  // Envía un mensaje al servidor WebSocket
  send(message: string) {
    this.socket.next(message);
  }

  // Escucha los mensajes del servidor WebSocket
  onMessage() {
    return this.socket.asObservable();
  }
}
