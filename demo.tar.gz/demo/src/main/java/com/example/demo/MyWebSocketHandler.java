package com.example.demo;

import org.springframework.stereotype.Component;
import org.springframework.web.reactive.socket.WebSocketHandler;
import org.springframework.web.reactive.socket.WebSocketMessage;
import org.springframework.web.reactive.socket.WebSocketSession;
import reactor.core.publisher.Mono;

@Component
public class MyWebSocketHandler implements WebSocketHandler {

    @Override
    public Mono<Void> handle(WebSocketSession session) {
        // Manejar la sesión WebSocket
        Mono<WebSocketMessage> messageMono = session.receive()
        .map(WebSocketMessage::getPayloadAsText)
        .map(this::processMessage)
        .map(session::textMessage)
        .single();

        return session.send(messageMono);
    }

    private String processMessage(String message) {
        // Procesar el mensaje recibido
        return "Processed: " + message;
    }
}