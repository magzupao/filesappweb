package com.ws.product.endpoint;

import com.ws.product.model.Producto;
import com.ws.product.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import java.util.List;

@Endpoint
public class ProductoEndpoint {

    private static final String NAMESPACE_URI = "https://www.cbk51.com/productservice";

    private ProductoService productoService;

    @Autowired
    public ProductoEndpoint(ProductoService productoService) {
        this.productoService = productoService;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "AgregarProductoRequest")
    @ResponsePayload
    public AgregarProductoResponse agregarProducto(@RequestPayload AgregarProductoRequest request) {
        Producto producto = new Producto(request.getCodigo(), request.getPrecio(), request.getDescripcion());
        productoService.agregarProducto(producto);
        AgregarProductoResponse response = new AgregarProductoResponse();
        response.setResultado("Producto agregado exitosamente");
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "ListarProductosRequest")
    @ResponsePayload
    public ListarProductosResponse listarProductos(@RequestPayload ListarProductosRequest request) {
        ListarProductosResponse response = new ListarProductosResponse();
        response.setProductos(productoService.listarProductos());
        return response;
    }

    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "BuscarProductoPorCodigoRequest")
    @ResponsePayload
    public BuscarProductoPorCodigoResponse buscarProductoPorCodigo(@RequestPayload BuscarProductoPorCodigoRequest request) {
        BuscarProductoPorCodigoResponse response = new BuscarProductoPorCodigoResponse();
        Producto producto = productoService.buscarPorCodigo(request.getCodigo()).orElse(null);
        response.setProducto(producto);
        return response;
    }
}

@XmlRootElement
class AgregarProductoRequest {
    private String codigo;
    private double precio;
    private String descripcion;

    // Getters y setters
    @XmlElement
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    @XmlElement
    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }

    @XmlElement
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }
}

@XmlRootElement
class AgregarProductoResponse {
    private String resultado;

    // Getter y setter
    @XmlElement
    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
}

@XmlRootElement
class ListarProductosRequest {
}

@XmlRootElement
class ListarProductosResponse {
    private List<Producto> productos;

    // Getter y setter
    @XmlElement
    public List<Producto> getProductos() {
        return productos;
    }

    public void setProductos(List<Producto> productos) {
        this.productos = productos;
    }
}

@XmlRootElement
class BuscarProductoPorCodigoRequest {
    private String codigo;

    // Getter y setter
    @XmlElement
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}

@XmlRootElement
class BuscarProductoPorCodigoResponse {
    private Producto producto;

    // Getter y setter
    @XmlElement
    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        this.producto = producto;
    }
}
